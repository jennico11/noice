# first: str = str(input())
# sec: str = str(input())
# new: str = ""
# i: int = 0
# if len(first) < len(sec):
#     while i < len(first): 
#         new += first[i]
#         new += sec[i]
#         i += 1
#     while i < len(sec):
#        new += sec[i]
#        i += 1
# else:
#     while i < len(sec):
#        new += first[i]
#        new += sec[i]
#        i += 1
#     while i < len(first): 
#         new += first[i]
#         i += 1
    
# print (new)

def decode(message: str, key: str) -> str:
    cracked: str = ""
    i: int = 0
    alphabet: str = "abcdefghijklmnopqrstuvwxyz"
    while i < len(message):
        position: int = 0
        letter: str = message[i]
        position = key.find(letter)
        if position == -1:
            cracked += letter
        else: 
            cracked += alphabet[position]
            first: str = key[0]
            key = key.replace(first, '')
            key += first
        i += 1
    return cracked

my_key = "qwertyuiopasdfghjklzxcvbnm"
my_message = "ehglnnan qslhmhl vjp xqxoeww mft tkkngxepcva hchrbvs feq znb vy fsmp, ecmz, mvds gez evzso. hte eoztszjgxd ke fqquojtstl brbsyogo; vsp nqedgny moip lv zcuq jd wgfgbkfoiwf uhbn gez evzso pwx wggtiznn qhqnylxepp eqnn."
print(decode(my_message, my_key))
            