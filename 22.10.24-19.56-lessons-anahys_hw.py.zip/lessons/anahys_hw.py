first: str = str(input())
sec: str = str(input())
new: str = ""
i: int = 0
if len(first) < len(sec):
    while i < len(first): 
        new += first[i]
        new += sec[i]
        i += 1
    while i < len(sec):
       new += sec[i]
       i += 1
else:
    while i < len(sec):
       new += first[i]
       new += sec[i]
       i += 1
    while i < len(first): 
        new += first[i]
        i += 1
    
print (new)